# angular-master-details-crud-example

Angular - Master Details CRUD Example

To see a demo and further details go to https://jasonwatmore.com/post/2020/09/01/angular-master-details-crud-example